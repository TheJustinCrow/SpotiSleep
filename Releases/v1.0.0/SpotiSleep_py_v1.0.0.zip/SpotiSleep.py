from PySide6 import QtCore, QtWidgets, QtGui
import sys
import subprocess

class SleepTimerWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        self.timer_running = False
        self.remaining_seconds = 0

        self.layout = QtWidgets.QVBoxLayout(self)
        self.layout.setAlignment(QtCore.Qt.AlignCenter)
        self.layout.setSpacing(10)
        self.setStyleSheet("background-color: #222; color: white;")

        self.layout.addStretch(1)

        self.logo_layout = QtWidgets.QHBoxLayout()
        self.layout.addLayout(self.logo_layout)

        self.logo_layout.addStretch(1)

        self.logo_label = QtWidgets.QLabel(self)
        self.logo_pixmap = QtGui.QPixmap("./SpotiSleep.png").scaledToWidth(300)
        self.logo_pixmap = self.logo_pixmap.copy()
        self.logo_pixmap.setDevicePixelRatio(2.0)
        self.logo_label.setPixmap(self.logo_pixmap)
        self.logo_label.setScaledContents(True)
        self.logo_layout.addWidget(self.logo_label)
        self.logo_layout.setAlignment(QtCore.Qt.AlignCenter)

        self.logo_layout.addStretch(1)

        self.layout.addStretch(1)

        self.countdown_label = QtWidgets.QLabel("Time Remaining: 00:00:00", self)
        font = QtGui.QFont("Helvetica", 16, weight=QtGui.QFont.Normal)
        self.countdown_label.setFont(font)
        self.countdown_label.setStyleSheet("color: #fff;")
        self.countdown_label.setAlignment(QtCore.Qt.AlignCenter)
        self.layout.addWidget(self.countdown_label)

        self.layout.addStretch(1)

        self.timer_input_layout = QtWidgets.QHBoxLayout()
        self.layout.addLayout(self.timer_input_layout)
        self.layout.addSpacing(5)

        self.hours_input = QtWidgets.QLineEdit(self)
        self.hours_input.setPlaceholderText("Hours")
        self.hours_input.setStyleSheet("""
            QLineEdit {
                border-radius: 15px;
                padding: 8px;
                font-size: 14px;
                width: 40px; /* Set width to 40 pixels */
                background-color: #333;
                color: white;
            }
        """)
        self.timer_input_layout.addWidget(self.hours_input)

        self.minutes_input = QtWidgets.QLineEdit(self)
        self.minutes_input.setPlaceholderText("Minutes")
        self.minutes_input.setStyleSheet("""
            QLineEdit {
                border-radius: 15px;
                padding: 8px;
                font-size: 14px;
                width: 40px; /* Set width to 40 pixels */
                background-color: #333;
                color: white;
            }
        """)
        self.timer_input_layout.addWidget(self.minutes_input)

        self.start_timer_button = QtWidgets.QPushButton("Start sleep timer", self)
        self.start_timer_button.setStyleSheet("""
            QPushButton {
                border-radius: 15px;
                background-color: #1DB954;
                color: white;
                font-family: Roboto;
                font-size: 14px;
                padding: 10px 15px;
                border: none;
                cursor: pointer;
            }
            QPushButton:hover {
                background-color: #32CD32;
            }
        """)
        self.start_timer_button.clicked.connect(self.handle_timer)
        self.layout.addWidget(self.start_timer_button)
        self.layout.addSpacing(5)

        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_timer_label)

        self.setFixedSize(400, 223)

    def update_countdown_label(self):
        if self.remaining_seconds <= 0:
            self.countdown_label.setText("Time Remaining: 00:00:00")
        else:
            hours = self.remaining_seconds // 3600
            minutes = (self.remaining_seconds % 3600) // 60
            seconds = self.remaining_seconds % 60

            self.countdown_label.setText(f"Time Remaining: {hours:02}:{minutes:02}:{seconds:02}")

    def update_timer_label(self):
        if self.timer_running:
            if self.remaining_seconds <= 0:
                self.timer.stop()
                self.timer_running = False
                self.close_spotify()
            else:
                self.remaining_seconds -= 1
                self.update_countdown_label()

    def close_spotify(self):
        subprocess.run(["taskkill", "/f", "/im", "spotify.exe"])

    def handle_timer(self):
        if not self.timer_running:
            hours = int(self.hours_input.text()) if self.hours_input.text().isdigit() else 0
            minutes = int(self.minutes_input.text()) if self.minutes_input.text().isdigit() else 0

            self.remaining_seconds = (hours * 3600) + (minutes * 60)
            self.timer_running = True
            self.timer.start(1000)

            self.hours_input.clear()
            self.hours_input.setPlaceholderText("Hours")
            self.minutes_input.clear()
            self.minutes_input.setPlaceholderText("Minutes")

            self.update_countdown_label()


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    app.setFont(QtGui.QFont("Helvetica"))

    window = SleepTimerWindow()
    window.setWindowTitle("SpotiSleep")

    icon = QtGui.QIcon("green.png")
    app.setWindowIcon(icon)

    window.show()

    sys.exit(app.exec())